const Order = require('../models/Order');
const Product = require('../models/Product');

exports.createOrder = async (req, res) => {
    const { userId, products, address } = req.body;

    try {
        // Calculate Total Price
        let totalAmount = 0;
        for (const item of products) {
            const product = await Product.findById(item.product);
            totalAmount += product.price * item.quantity;
        }

        // Create Order
        const newOrder = new Order({
            user: userId,
            products,
            totalAmount,
            address,
        });

        await newOrder.save();
        res.status(201).json({ message: 'Order placed successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to place order' });
    }
};

exports.getOrders = async (req, res) => {
    try {
        const orders = await Order.find().populate('user').populate('products.product');
        res.json(orders);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
};
